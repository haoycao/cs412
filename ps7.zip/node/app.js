// app.js
const express = require('express');
const app = express();
const ps4Router = require('./routes/ps4');

app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

app.use('/ps4', ps4Router);
app.get('/', (req, res) => {
    res.render('form');
});
app.listen(3000, () => {
    console.log('Server running on port 3000');
});// Error handling middleware








