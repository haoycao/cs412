const express = require('express');
const router = express.Router();
const request = require('request-promise-native');
const https = require("https");

const api= "https://api.openweathermap.org/data/2.5/weather?q=London,uk&APPID=2efe5532d96af4d226fce4c681deaea6";

// Route using Promises
/*
router.get('/', (req, res) => {
    const url = api;

    const getWeather = () => {
        return new Promise((resolve, reject) => {
            request(url, (error, response, body) => {
                if (error) {
                    reject(error);
                } else {
                    resolve(JSON.parse(body));
                }
            });
        });
    };

    getWeather()
        .then(data => {res.json({ temp: data.main.temp });

        }).then(data => res.render('ps4', { temperature: data.main.temp }))
        .catch(error => res.status(500).json({ error }));
});
*/
// Route using async/await
router.get('/', async (req, res) => {
    const url = api

    try {
        const response = await fetch(url);
        const data = await response.json();

        const temper= data.main.temp;

       // console.log(1);
        res.render('ps4', {  temp:   temper });
    } catch (error) {
        res.status(500).json({ error });
    }
});
//callback
/*
router.get('/', (req, res) => {
    const url = api;

    request(url, (error, response, body) => {
        if (error) {
            res.status(500).json({ error });
        } else {
            const data = JSON.parse(body);

            // Adding a time delay using setTimeout
            setTimeout(() => {
                res.json({ temp: data.main.temp });
                const temper= data.main.temp;
                res.render('ps4', {  temp:   temper });
            }, 1000); // 1000 milliseconds (1 second) delay
        }
    });
});
*/
module.exports = router;


